'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { User as UserIcon, Lock } from 'lucide-react';
import MountainScape from '@/components/MountainScape';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function attemptLogin() {
    if (!username.trim() || !password) {
      setErr('Isi username dan password terlebih dahulu.');
      return;
    }
    setBusy(true);
    setErr('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(data.error || 'Username atau password salah.');
        setBusy(false);
        return;
      }
      router.push('/dashboard');
      router.refresh();
    } catch {
      setErr('Tidak bisa terhubung ke server. Coba lagi.');
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <MountainScape />
      <div className="login-card">
        <div className="login-badge"><span className="dot" />Sistem Gudang &middot; Stok &amp; Distribusi</div>
        <h1 className="disp">Masuk ke Gudang</h1>
        <p className="sub">Masukkan username dan password untuk mencatat stok.</p>
        {err && <div className="login-error">{err}</div>}
        <form onSubmit={(e) => { e.preventDefault(); attemptLogin(); }} noValidate>
          <div className="field">
            <label htmlFor="username">Username</label>
            <div className="input-row">
              <UserIcon size={16} />
              <input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="cth. farrel"
                autoComplete="username"
              />
            </div>
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <div className="input-row">
              <Lock size={16} />
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
              />
            </div>
          </div>
          <button className="btn-accent" type="button" disabled={busy} onClick={attemptLogin}>
            {busy ? 'Memuat...' : 'Masuk'}
          </button>
        </form>
        <p className="login-hint">
          Login: <strong>farrel</strong> atau <strong>aim</strong>, password <strong>admingudang</strong> (default —
          bisa diganti lewat environment variable, lihat README).
        </p>
      </div>
    </div>
  );
}
