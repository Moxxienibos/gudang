import { NextResponse } from 'next/server';
import { storeGet, storeSet, KEY_PRODUCTS } from '@/lib/store';
import { getSession } from '@/lib/authGuard';
import seedData from '@/lib/seed-data.json';

export async function GET(req) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let products = await storeGet(KEY_PRODUCTS);
  if (!products) {
    products = seedData;
    await storeSet(KEY_PRODUCTS, products);
  }
  return NextResponse.json(products);
}

export async function POST(req) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (session.role !== 'admin') {
    return NextResponse.json({ error: 'Hanya admin yang bisa menambah produk.' }, { status: 403 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Permintaan tidak valid.' }, { status: 400 });
  }

  const name = (body.name || '').trim();
  if (!name) return NextResponse.json({ error: 'Nama produk wajib diisi.' }, { status: 400 });

  const products = (await storeGet(KEY_PRODUCTS)) || seedData;
  const newProduct = {
    id: 'p' + Date.now() + Math.floor(Math.random() * 1000),
    name,
    unit: (body.unit || '').trim() || 'Pc(s)',
    qty: 0,
    minStock: Number(body.minStock) || 0,
  };
  const updated = [...products, newProduct];
  await storeSet(KEY_PRODUCTS, updated);
  return NextResponse.json(newProduct, { status: 201 });
}
