import { NextResponse } from 'next/server';
import { storeGet, storeSet, KEY_PRODUCTS } from '@/lib/store';
import { getSession } from '@/lib/authGuard';
import seedData from '@/lib/seed-data.json';

export async function PATCH(req, { params }) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (session.role !== 'admin') {
    return NextResponse.json({ error: 'Hanya admin yang bisa mengubah produk.' }, { status: 403 });
  }

  let patch;
  try {
    patch = await req.json();
  } catch {
    return NextResponse.json({ error: 'Permintaan tidak valid.' }, { status: 400 });
  }

  const products = (await storeGet(KEY_PRODUCTS)) || seedData;
  const exists = products.some((p) => p.id === params.id);
  if (!exists) return NextResponse.json({ error: 'Produk tidak ditemukan.' }, { status: 404 });

  const safePatch = {};
  if (typeof patch.name === 'string' && patch.name.trim()) safePatch.name = patch.name.trim();
  if (typeof patch.unit === 'string' && patch.unit.trim()) safePatch.unit = patch.unit.trim();
  if (patch.minStock !== undefined) safePatch.minStock = Number(patch.minStock) || 0;

  const updated = products.map((p) => (p.id === params.id ? { ...p, ...safePatch } : p));
  await storeSet(KEY_PRODUCTS, updated);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req, { params }) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (session.role !== 'admin') {
    return NextResponse.json({ error: 'Hanya admin yang bisa menghapus produk.' }, { status: 403 });
  }

  const products = (await storeGet(KEY_PRODUCTS)) || seedData;
  const updated = products.filter((p) => p.id !== params.id);
  await storeSet(KEY_PRODUCTS, updated);
  return NextResponse.json({ ok: true });
}
