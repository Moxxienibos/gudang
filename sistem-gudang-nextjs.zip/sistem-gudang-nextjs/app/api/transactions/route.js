import { NextResponse } from 'next/server';
import { storeGet, storeSet, KEY_PRODUCTS, KEY_TRANSACTIONS } from '@/lib/store';
import { getSession } from '@/lib/authGuard';
import seedData from '@/lib/seed-data.json';

export async function GET(req) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const tx = (await storeGet(KEY_TRANSACTIONS)) || [];
  return NextResponse.json(tx);
}

export async function POST(req) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Permintaan tidak valid.' }, { status: 400 });
  }

  const { type, productId, date } = body;
  const qty = Number(body.qty);

  if (type !== 'in' && type !== 'out') {
    return NextResponse.json({ error: 'Tipe transaksi tidak valid.' }, { status: 400 });
  }
  if (!productId) {
    return NextResponse.json({ error: 'Barang wajib dipilih.' }, { status: 400 });
  }
  if (!qty || qty <= 0) {
    return NextResponse.json({ error: 'Jumlah harus lebih dari 0.' }, { status: 400 });
  }
  if (type === 'in' && !(body.supplier || '').trim()) {
    return NextResponse.json({ error: 'Isi nama supplier.' }, { status: 400 });
  }
  if (type === 'out' && !(body.division || '').trim()) {
    return NextResponse.json({ error: 'Pilih divisi tujuan.' }, { status: 400 });
  }

  const products = (await storeGet(KEY_PRODUCTS)) || seedData;
  const prod = products.find((p) => p.id === productId);
  if (!prod) return NextResponse.json({ error: 'Barang tidak ditemukan.' }, { status: 404 });

  if (type === 'out' && qty > prod.qty) {
    return NextResponse.json(
      { error: `Stok tidak cukup. Sisa stok ${prod.qty} ${prod.unit}.` },
      { status: 400 }
    );
  }

  const updatedProducts = products.map((p) =>
    p.id === productId ? { ...p, qty: type === 'in' ? p.qty + qty : p.qty - qty } : p
  );

  const tx = {
    id: 'tx' + Date.now() + Math.floor(Math.random() * 1000),
    type,
    productId,
    productName: prod.name,
    qty,
    unit: prod.unit,
    date: date || new Date().toISOString().slice(0, 10),
    supplier: type === 'in' ? (body.supplier || '').trim() : '',
    division: type === 'out' ? (body.division || '').trim() : '',
    timestamp: Date.now(),
    createdBy: session.username,
  };

  const existingTx = (await storeGet(KEY_TRANSACTIONS)) || [];
  const updatedTx = [...existingTx, tx];

  await storeSet(KEY_PRODUCTS, updatedProducts);
  await storeSet(KEY_TRANSACTIONS, updatedTx);

  return NextResponse.json(tx, { status: 201 });
}
