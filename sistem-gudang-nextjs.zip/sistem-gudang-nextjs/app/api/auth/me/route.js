import { NextResponse } from 'next/server';
import { getSession } from '@/lib/authGuard';

export async function GET(req) {
  const session = getSession(req);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  return NextResponse.json({ username: session.username, role: session.role });
}
