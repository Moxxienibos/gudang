import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifySessionToken, SESSION_COOKIE } from '@/lib/session';
import { ToastProvider } from '@/components/Toast';
import Sidebar from '@/components/Sidebar';
import { storeGet, KEY_PRODUCTS } from '@/lib/store';
import seedData from '@/lib/seed-data.json';

export default async function AppLayout({ children }) {
  const cookieStore = cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  const session = verifySessionToken(token);

  if (!session) {
    redirect('/login');
  }

  const products = (await storeGet(KEY_PRODUCTS)) || seedData;
  const lowStockCount = products.filter((p) => p.qty <= p.minStock).length;

  return (
    <ToastProvider>
      <div className="shell">
        <Sidebar user={session} lowStockCount={lowStockCount} />
        <div className="main">{children}</div>
      </div>
    </ToastProvider>
  );
}
