'use client';

import { useEffect, useMemo, useState } from 'react';
import { Search, Download, ChevronLeft, ChevronRight, ArrowDownToLine, ArrowUpFromLine } from 'lucide-react';
import * as XLSX from 'xlsx';
import { apiGet } from '@/lib/api';
import { fmtDate, fmtTime, fmtQty, todayISO } from '@/lib/format';

const PER_PAGE = 40;

export default function RiwayatPage() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(0);

  useEffect(() => {
    apiGet('/api/transactions').then(setTransactions).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    let list = [...transactions].sort((a, b) => b.timestamp - a.timestamp);
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter((tx) =>
        tx.productName.toLowerCase().includes(t) ||
        (tx.supplier || '').toLowerCase().includes(t) ||
        (tx.division || '').toLowerCase().includes(t)
      );
    }
    if (type) list = list.filter((tx) => tx.type === type);
    if (dateFrom) list = list.filter((tx) => tx.date >= dateFrom);
    if (dateTo) list = list.filter((tx) => tx.date <= dateTo);
    return list;
  }, [transactions, q, type, dateFrom, dateTo]);

  useEffect(() => { setPage(0); }, [q, type, dateFrom, dateTo]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const pageItems = filtered.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  function exportXlsx() {
    const rows = filtered.map((tx) => ({
      Tanggal: fmtDate(tx.date),
      Tipe: tx.type === 'in' ? 'Barang Masuk' : 'Barang Keluar',
      'Nama Barang': tx.productName,
      Jumlah: tx.qty,
      Satuan: tx.unit,
      Supplier: tx.supplier || '',
      'Divisi Tujuan': tx.division || '',
      Waktu: fmtTime(tx.timestamp),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Riwayat');
    XLSX.writeFile(wb, `riwayat-transaksi-${todayISO()}.xlsx`);
  }

  return (
    <>
      <div className="page-head">
        <div className="eyebrow">Rujukan</div>
        <h1 className="disp">Riwayat Transaksi</h1>
        <p>Semua catatan barang masuk dan keluar, bisa disaring dan diunduh sebagai laporan.</p>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari barang, supplier, atau divisi..." aria-label="Cari riwayat" />
        </div>
        <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Filter tipe">
          <option value="">Semua Tipe</option>
          <option value="in">Barang Masuk</option>
          <option value="out">Barang Keluar</option>
        </select>
        <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} aria-label="Dari tanggal" />
        <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} aria-label="Sampai tanggal" />
        <button className="btn-export" onClick={exportXlsx}><Download size={14} />Export Excel</button>
      </div>

      <div className="tbl-wrap">
        {loading ? (
          <p style={{ color: 'var(--muted)', padding: 20 }}>Memuat data...</p>
        ) : (
          <>
            <table>
              <thead>
                <tr><th>Tanggal</th><th>Tipe</th><th>Nama Barang</th><th style={{ textAlign: 'right' }}>Jumlah</th><th>Supplier / Divisi</th></tr>
              </thead>
              <tbody>
                {pageItems.length === 0 ? (
                  <tr><td colSpan={5} className="empty-note">Tidak ada transaksi yang cocok dengan filter ini.</td></tr>
                ) : (
                  pageItems.map((tx) => (
                    <tr key={tx.id}>
                      <td className="mono">{fmtDate(tx.date)}</td>
                      <td>
                        <span className={`type-flag ${tx.type}`}>
                          {tx.type === 'in' ? <ArrowDownToLine size={11} /> : <ArrowUpFromLine size={11} />}
                          {tx.type === 'in' ? 'Masuk' : 'Keluar'}
                        </span>
                      </td>
                      <td>{tx.productName}</td>
                      <td className="qty-cell" style={{ textAlign: 'right' }}>{tx.type === 'in' ? '+' : '-'}{fmtQty(tx.qty)} {tx.unit}</td>
                      <td style={{ color: 'var(--muted)' }}>{tx.type === 'in' ? (tx.supplier || '-') : (tx.division || '-')}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="pager">
              <div className="info">{filtered.length.toLocaleString('id-ID')} transaksi &middot; halaman {page + 1} / {totalPages}</div>
              <div className="btns">
                <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} aria-label="Halaman sebelumnya"><ChevronLeft size={15} /></button>
                <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} aria-label="Halaman berikutnya"><ChevronRight size={15} /></button>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
