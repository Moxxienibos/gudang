'use client';

import { useEffect, useState } from 'react';
import { apiGet, apiPost } from '@/lib/api';
import { useToast } from '@/components/Toast';
import ProductPicker from '@/components/ProductPicker';
import { todayISO, DIVISIONS, fmtQty } from '@/lib/format';

export default function BarangKeluarPage() {
  const pushToast = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [qty, setQty] = useState('');
  const [date, setDate] = useState(todayISO());
  const [division, setDivision] = useState(DIVISIONS[0]);
  const [divisionOther, setDivisionOther] = useState('');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    apiGet('/api/products').then(setProducts).finally(() => setLoading(false));
  }, []);

  async function submit(e) {
    e.preventDefault();
    if (!selected) { setMsg({ type: 'err', text: 'Pilih barang terlebih dahulu.' }); return; }
    const q = parseFloat(qty);
    if (!q || q <= 0) { setMsg({ type: 'err', text: 'Jumlah harus lebih dari 0.' }); return; }
    if (q > selected.qty) { setMsg({ type: 'err', text: `Stok tidak cukup. Sisa stok ${fmtQty(selected.qty)} ${selected.unit}.` }); return; }
    const finalDivision = division === 'Lainnya' ? divisionOther.trim() : division;
    if (division === 'Lainnya' && !finalDivision) { setMsg({ type: 'err', text: 'Isi nama divisi/jenisnya terlebih dahulu.' }); return; }

    setBusy(true);
    try {
      await apiPost('/api/transactions', {
        type: 'out', productId: selected.id, qty: q, date, division: finalDivision,
      });
      pushToast('ok', `${q} ${selected.unit} ${selected.name} tercatat keluar ke ${finalDivision}.`);
      setProducts((ps) => ps.map((p) => (p.id === selected.id ? { ...p, qty: p.qty - q } : p)));
      setSelected(null); setQty(''); setDate(todayISO()); setDivision(DIVISIONS[0]); setDivisionOther(''); setMsg(null);
    } catch (err) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-head">
        <div className="eyebrow">Pencatatan</div>
        <h1 className="disp">Barang Keluar</h1>
        <p>Catat pengeluaran barang dan tujuannya untuk mengurangi stok gudang.</p>
      </div>
      <div className="form-panel">
        {loading ? (
          <p style={{ color: 'var(--muted)' }}>Memuat daftar barang...</p>
        ) : (
          <form onSubmit={submit}>
            <div className="field no-icon">
              <label>Nama Barang</label>
              <ProductPicker products={products} selected={selected} onSelect={setSelected} />
            </div>
            <div className="form-grid">
              <div className="field no-icon">
                <label htmlFor="qty-out">Jumlah {selected ? `(${selected.unit})` : ''}</label>
                <input id="qty-out" type="number" min="0" step="any" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="0" />
              </div>
              <div className="field no-icon">
                <label htmlFor="date-out">Tanggal</label>
                <input id="date-out" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div className="field no-icon span2">
                <label htmlFor="division">Divisi Tujuan</label>
                <select id="division" value={division} onChange={(e) => setDivision(e.target.value)}>
                  {DIVISIONS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              {division === 'Lainnya' && (
                <div className="field no-icon span2">
                  <label htmlFor="division-other">Jenis Divisi Lainnya</label>
                  <input id="division-other" value={divisionOther} onChange={(e) => setDivisionOther(e.target.value)} placeholder="Tulis nama divisi/jenisnya" />
                </div>
              )}
            </div>
            <div className="form-actions">
              <button className="btn-primary" type="button" disabled={busy} onClick={submit}>{busy ? 'Menyimpan...' : 'Tambah'}</button>
              <button className="btn-secondary" type="button" onClick={() => { setSelected(null); setQty(''); setDivision(DIVISIONS[0]); setDivisionOther(''); setMsg(null); }}>Reset</button>
            </div>
            {msg && <div className={`form-msg ${msg.type === 'ok' ? 'ok' : 'err'}`}>{msg.text}</div>}
          </form>
        )}
      </div>
    </>
  );
}
