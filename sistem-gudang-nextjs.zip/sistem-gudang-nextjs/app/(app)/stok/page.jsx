'use client';

import { useEffect, useMemo, useState } from 'react';
import { Search, AlertTriangle, ChevronLeft, ChevronRight } from 'lucide-react';
import { apiGet } from '@/lib/api';
import { fmtQty } from '@/lib/format';

const PER_PAGE = 40;

export default function StokBarangPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [unit, setUnit] = useState('');
  const [lowOnly, setLowOnly] = useState(false);
  const [page, setPage] = useState(0);

  useEffect(() => {
    apiGet('/api/products').then(setProducts).finally(() => setLoading(false));
  }, []);

  const units = useMemo(() => [...new Set(products.map((p) => p.unit))].sort(), [products]);

  const filtered = useMemo(() => {
    let list = products;
    if (q.trim()) { const t = q.toLowerCase(); list = list.filter((p) => p.name.toLowerCase().includes(t)); }
    if (unit) list = list.filter((p) => p.unit === unit);
    if (lowOnly) list = list.filter((p) => p.qty <= p.minStock);
    return list;
  }, [products, q, unit, lowOnly]);

  useEffect(() => { setPage(0); }, [q, unit, lowOnly]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const pageItems = filtered.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  return (
    <>
      <div className="page-head">
        <div className="eyebrow">Rujukan</div>
        <h1 className="disp">Stok Barang</h1>
        <p>Lihat jumlah stok seluruh produk gudang, saring berdasarkan satuan atau stok menipis.</p>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari nama barang..." aria-label="Cari barang" />
        </div>
        <select value={unit} onChange={(e) => setUnit(e.target.value)} aria-label="Filter satuan">
          <option value="">Semua Satuan</option>
          {units.map((u) => <option key={u} value={u}>{u}</option>)}
        </select>
        <label className="chk-label">
          <input type="checkbox" checked={lowOnly} onChange={(e) => setLowOnly(e.target.checked)} />
          Stok menipis saja
        </label>
      </div>

      <div className="tbl-wrap">
        {loading ? (
          <p style={{ color: 'var(--muted)', padding: 20 }}>Memuat data...</p>
        ) : (
          <>
            <table>
              <thead>
                <tr><th>Nama Barang</th><th>Satuan</th><th style={{ textAlign: 'right' }}>Stok</th><th style={{ textAlign: 'right' }}>Ambang Minimum</th></tr>
              </thead>
              <tbody>
                {pageItems.length === 0 ? (
                  <tr><td colSpan={4} className="empty-note">Tidak ada barang yang cocok dengan pencarian ini.</td></tr>
                ) : (
                  pageItems.map((p) => (
                    <tr key={p.id}>
                      <td>
                        {p.name}
                        {p.qty <= p.minStock && <span className="low-flag"><AlertTriangle size={11} />menipis</span>}
                      </td>
                      <td className="mono">{p.unit}</td>
                      <td className="qty-cell" style={{ textAlign: 'right' }}>{fmtQty(p.qty)}</td>
                      <td className="qty-cell" style={{ textAlign: 'right', color: 'var(--muted-2)' }}>{fmtQty(p.minStock)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="pager">
              <div className="info">{filtered.length.toLocaleString('id-ID')} barang &middot; halaman {page + 1} / {totalPages}</div>
              <div className="btns">
                <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} aria-label="Halaman sebelumnya"><ChevronLeft size={15} /></button>
                <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} aria-label="Halaman berikutnya"><ChevronRight size={15} /></button>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
