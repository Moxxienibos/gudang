'use client';

import { useEffect, useMemo, useState } from 'react';
import { Search, Plus, Pencil, Trash2, AlertTriangle, ShieldCheck, ChevronLeft, ChevronRight } from 'lucide-react';
import { apiGet, apiPost, apiPatch, apiDelete } from '@/lib/api';
import { useToast } from '@/components/Toast';
import { fmtQty } from '@/lib/format';

const PER_PAGE = 40;

export default function KelolaProdukPage() {
  const pushToast = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [canEdit, setCanEdit] = useState(false);
  const [q, setQ] = useState('');
  const [page, setPage] = useState(0);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [name, setName] = useState('');
  const [unit, setUnit] = useState('Pc(s)');
  const [minStock, setMinStock] = useState('3');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [toDelete, setToDelete] = useState(null);

  useEffect(() => {
    Promise.all([apiGet('/api/products'), apiGet('/api/auth/me')])
      .then(([p, me]) => { setProducts(p); setCanEdit(me.role === 'admin'); })
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    if (!q.trim()) return products;
    const t = q.toLowerCase();
    return products.filter((p) => p.name.toLowerCase().includes(t));
  }, [products, q]);
  useEffect(() => { setPage(0); }, [q]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const pageItems = filtered.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  function openAdd() {
    setEditing(null); setName(''); setUnit('Pc(s)'); setMinStock('3'); setMsg(null); setShowForm(true);
  }
  function openEdit(p) {
    setEditing(p); setName(p.name); setUnit(p.unit); setMinStock(String(p.minStock)); setMsg(null); setShowForm(true);
  }

  async function submit(e) {
    e.preventDefault();
    if (!name.trim()) { setMsg({ type: 'err', text: 'Nama produk wajib diisi.' }); return; }
    setBusy(true);
    try {
      if (editing) {
        await apiPatch(`/api/products/${editing.id}`, { name: name.trim(), unit: unit.trim() || 'Pc(s)', minStock: parseFloat(minStock) || 0 });
        setProducts((ps) => ps.map((p) => (p.id === editing.id ? { ...p, name: name.trim(), unit: unit.trim() || 'Pc(s)', minStock: parseFloat(minStock) || 0 } : p)));
        pushToast('ok', 'Produk berhasil diubah.');
      } else {
        const created = await apiPost('/api/products', { name: name.trim(), unit: unit.trim() || 'Pc(s)', minStock: parseFloat(minStock) || 0 });
        setProducts((ps) => [...ps, created]);
        pushToast('ok', `Produk "${name.trim()}" ditambahkan.`);
      }
      setShowForm(false);
    } catch (err) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    try {
      await apiDelete(`/api/products/${toDelete.id}`);
      setProducts((ps) => ps.filter((p) => p.id !== toDelete.id));
      pushToast('ok', `"${toDelete.name}" dihapus.`);
    } catch (err) {
      pushToast('err', err.message);
    } finally {
      setToDelete(null);
    }
  }

  return (
    <>
      <div className="page-head">
        <div className="eyebrow">Master Data</div>
        <h1 className="disp">Kelola Produk</h1>
        <p>Tambah, ubah, atau hapus produk yang tercatat di gudang.</p>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari nama barang..." aria-label="Cari produk" />
        </div>
        {canEdit && (
          <button className="btn-primary" style={{ display: 'flex', alignItems: 'center', gap: 7 }} onClick={openAdd}>
            <Plus size={15} />Tambah Produk
          </button>
        )}
      </div>

      {!loading && !canEdit && (
        <div className="no-access">
          <ShieldCheck size={18} color="var(--accent)" style={{ flexShrink: 0 }} />
          <span>Kamu login sebagai Staff — hanya bisa melihat daftar produk. Hubungi Farrel untuk menambah, mengubah, atau menghapus produk.</span>
        </div>
      )}

      {showForm && (
        <div className="modal-backdrop" onClick={() => setShowForm(false)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h3>{editing ? 'Ubah Produk' : 'Tambah Produk'}</h3>
            <form onSubmit={submit}>
              <div className="field no-icon">
                <label htmlFor="p-name">Nama Produk</label>
                <input id="p-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="cth. TEPUNG TERIGU CAKRA" />
              </div>
              <div className="form-grid">
                <div className="field no-icon">
                  <label htmlFor="p-unit">Satuan Default</label>
                  <input id="p-unit" value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="kg / Pc(s) / Pack" />
                </div>
                <div className="field no-icon">
                  <label htmlFor="p-min">Ambang Stok Menipis</label>
                  <input id="p-min" type="number" min="0" step="any" value={minStock} onChange={(e) => setMinStock(e.target.value)} />
                </div>
              </div>
              {msg && <div className="form-msg err">{msg.text}</div>}
              <div className="modal-actions">
                <button className="btn-secondary" type="button" onClick={() => setShowForm(false)}>Batal</button>
                <button className="btn-primary" type="submit" disabled={busy}>{busy ? 'Menyimpan...' : (editing ? 'Simpan' : 'Tambah Produk')}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {toDelete && (
        <div className="modal-backdrop" onClick={() => setToDelete(null)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h3><AlertTriangle size={17} color="var(--red)" />Hapus Produk?</h3>
            <p>&quot;{toDelete.name}&quot; akan dihapus dari master data. Riwayat transaksi yang sudah ada tidak akan terhapus. Tindakan ini tidak dapat dibatalkan.</p>
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setToDelete(null)}>Batal</button>
              <button className="btn-danger" onClick={confirmDelete}>Hapus</button>
            </div>
          </div>
        </div>
      )}

      <div className="tbl-wrap">
        {loading ? (
          <p style={{ color: 'var(--muted)', padding: 20 }}>Memuat data...</p>
        ) : (
          <>
            <table>
              <thead>
                <tr><th>Nama Barang</th><th>Satuan</th><th style={{ textAlign: 'right' }}>Stok</th><th style={{ textAlign: 'right' }}>Ambang Min.</th><th></th></tr>
              </thead>
              <tbody>
                {pageItems.length === 0 ? (
                  <tr><td colSpan={5} className="empty-note">Tidak ada produk yang cocok. Coba kata kunci lain atau tambah produk baru.</td></tr>
                ) : (
                  pageItems.map((p) => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td className="mono">{p.unit}</td>
                      <td className="qty-cell" style={{ textAlign: 'right' }}>{fmtQty(p.qty)}</td>
                      <td className="qty-cell" style={{ textAlign: 'right', color: 'var(--muted-2)' }}>{fmtQty(p.minStock)}</td>
                      <td>
                        {canEdit && (
                          <div className="row-actions">
                            <button className="icon-btn" onClick={() => openEdit(p)} aria-label={`Ubah ${p.name}`}><Pencil /></button>
                            <button className="icon-btn danger" onClick={() => setToDelete(p)} aria-label={`Hapus ${p.name}`}><Trash2 /></button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            <div className="pager">
              <div className="info">{filtered.length.toLocaleString('id-ID')} produk &middot; halaman {page + 1} / {totalPages}</div>
              <div className="btns">
                <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} aria-label="Halaman sebelumnya"><ChevronLeft size={15} /></button>
                <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} aria-label="Halaman berikutnya"><ChevronRight size={15} /></button>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
