'use client';

import { useEffect, useMemo, useState } from 'react';
import { Package, AlertTriangle, History, ArrowDownToLine, ArrowUpFromLine } from 'lucide-react';
import { apiGet } from '@/lib/api';
import { fmtDate, fmtQty, fmtTime, todayISO } from '@/lib/format';

export default function DashboardPage() {
  const [products, setProducts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([apiGet('/api/products'), apiGet('/api/transactions')])
      .then(([p, t]) => { setProducts(p); setTransactions(t); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const lowStock = products.filter((p) => p.qty <= p.minStock);
  const today = todayISO();
  const txToday = transactions.filter((t) => t.date === today).length;
  const recent = useMemo(
    () => [...transactions].sort((a, b) => b.timestamp - a.timestamp).slice(0, 10),
    [transactions]
  );
  const byUnit = useMemo(() => {
    const map = {};
    products.forEach((p) => { map[p.unit] = (map[p.unit] || 0) + p.qty; });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [products]);
  const maxUnit = byUnit.length ? byUnit[0][1] : 1;

  if (loading) return <p style={{ color: 'var(--muted)' }}>Memuat data...</p>;
  if (error) return <p style={{ color: 'var(--red)' }}>{error}</p>;

  return (
    <>
      <div className="page-head">
        <div className="eyebrow">Ringkasan</div>
        <h1 className="disp">Ringkasan Gudang</h1>
        <p>Pantau stok, aktivitas terbaru, dan barang yang perlu segera diisi ulang.</p>
      </div>

      <div className="cards-row">
        <div className="stat-card">
          <div className="card-top"><div className="lbl">Total Produk</div><div className="card-icon"><Package size={15} /></div></div>
          <div className="val">{products.length.toLocaleString('id-ID')}</div>
          <div className="foot">terdaftar di master data</div>
        </div>
        <div className={`stat-card${lowStock.length > 0 ? ' warn' : ''}`}>
          <div className="card-top"><div className="lbl">Stok Menipis</div><div className="card-icon"><AlertTriangle size={15} /></div></div>
          <div className={`val ${lowStock.length > 0 ? 'red' : ''}`}>{lowStock.length}</div>
          <div className="foot">{lowStock.length > 0 ? 'butuh diisi ulang segera' : 'semua stok aman'}</div>
        </div>
        <div className="stat-card">
          <div className="card-top"><div className="lbl">Transaksi Hari Ini</div><div className="card-icon"><History size={15} /></div></div>
          <div className="val accent">{txToday}</div>
          <div className="foot">{fmtDate(today)}</div>
        </div>
      </div>

      <div className="two-col">
        <div className="panel-box">
          <h3>Aktivitas Terbaru</h3>
          <p className="panel-sub">10 transaksi terakhir, masuk dan keluar</p>
          {recent.length === 0 ? (
            <div className="empty-note">Belum ada transaksi. Catat barang masuk atau keluar untuk mulai mengisi riwayat ini.</div>
          ) : (
            recent.map((t) => (
              <div className="activity-row" key={t.id}>
                <div className={`activity-icon ${t.type}`}>
                  {t.type === 'in' ? <ArrowDownToLine /> : <ArrowUpFromLine />}
                </div>
                <div className="activity-main">
                  <div className="nm">{t.productName}</div>
                  <div className="meta">
                    {fmtTime(t.timestamp)}
                    {t.type === 'out' && t.division ? ` · ke ${t.division}` : ''}
                    {t.type === 'in' && t.supplier ? ` · dari ${t.supplier}` : ''}
                  </div>
                </div>
                <div className={`activity-qty mono ${t.type}`}>
                  {t.type === 'in' ? '+' : '-'}{fmtQty(t.qty)} {t.unit}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="panel-box">
          <h3>Total Stok per Satuan</h3>
          <p className="panel-sub">enam satuan dengan jumlah stok terbesar</p>
          {byUnit.map(([unit, qty]) => (
            <div className="silo-row" key={unit}>
              <div className="silo-label mono">{unit}</div>
              <div className="silo-track"><div className="silo-fill" style={{ width: `${Math.max(4, (qty / maxUnit) * 100)}%` }} /></div>
              <div className="silo-val mono">{fmtQty(qty)}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
