import './globals.css';

export const metadata = {
  title: 'Sistem Gudang',
  description: 'Pengelolaan stok dan distribusi barang gudang.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
