# Sistem Gudang — Next.js + Vercel

Aplikasi pengelolaan stok gudang full-stack yang bisa langsung di-deploy ke Vercel. Sudah include data 1.676 produk dari file Excel kamu.

## Fitur

- **Login dua akun** — Farrel (admin, full access) & Aim (staff, hanya lihat & input)
- **Barang Masuk/Keluar** — catat penerimaan dari supplier & pengeluaran ke divisi (19 divisi Woila)
- **Stok & Riwayat** — lihat stok real-time, filter, dan export laporan ke Excel
- **Hak Akses** — Admin bisa tambah/ubah/hapus produk; Staff cuma bisa input transaksi
- **Notifikasi** — Toast notifications pas setiap aksi berhasil/gagal
- **Design** — minimalis, bukan norak (halaman login punya gunung background garis tipis)

## Deploy ke Vercel (5 menit)

### 1. Push ke GitHub
```bash
cd sistem-gudang-nextjs
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/sistem-gudang.git
git push -u origin main
```

### 2. Buat Vercel Project
- Buka https://vercel.com
- Click "Add New..." → "Project"
- Select repo `sistem-gudang` yang baru saja di-push
- Framework: Next.js (auto-detect)
- Click "Deploy"

Vercel otomatis build & deploy. Tunggu ~1 menit, selesai!

### 3. (Opsional) Setup Vercel KV untuk Persistent Storage

**Tanpa KV:** Data hanya bertahan selama satu deployment berjalan. Kalau app di-redeploy atau idle terlalu lama, data hilang.

**Dengan KV:** Data tersimpan permanen.

Cara setup:
- Di Vercel dashboard project kamu, tab "Storage"
- Click "Create Database" → "KV"
- Ikuti wizard (pilih region terdekat)
- Vercel otomatis set `KV_REST_API_URL` dan `KV_REST_API_TOKEN` sebagai environment variable
- Selesai!

## Development Lokal

### Setup
```bash
npm install
npm run dev
```

Buka http://localhost:3000/login

Login pakai: `farrel` / `admingudang` (admin) atau `aim` / `admingudang` (staff)

### Storage
- **Lokal** (dev): data tersimpan di `.local-data.json` di root folder (git-ignore)
- **Vercel**: pakai environment variable `KV_REST_API_URL` + `KV_REST_API_TOKEN` (kalau sudah setup KV)

## File Structure

```
sistem-gudang-nextjs/
├── app/
│   ├── api/
│   │   ├── auth/
│   │   │   ├── login/route.js       # Login endpoint
│   │   │   ├── logout/route.js      # Logout endpoint
│   │   │   └── me/route.js          # Check session endpoint
│   │   ├── products/
│   │   │   ├── route.js             # GET all, POST create
│   │   │   └── [id]/route.js        # PATCH update, DELETE
│   │   └── transactions/route.js    # GET all, POST create (masuk/keluar)
│   ├── (app)/
│   │   ├── layout.jsx               # Auth check, session validation
│   │   ├── dashboard/page.jsx       # Dashboard
│   │   ├── masuk/page.jsx           # Barang Masuk
│   │   ├── keluar/page.jsx          # Barang Keluar
│   │   ├── stok/page.jsx            # Stok Barang
│   │   ├── riwayat/page.jsx         # Riwayat Transaksi
│   │   └── produk/page.jsx          # Kelola Produk (admin only)
│   ├── login/page.jsx               # Login page
│   ├── layout.js                    # Root layout
│   └── page.js                      # Redirect to dashboard
├── components/
│   ├── MountainScape.jsx            # Background SVG buat login
│   ├── Toast.jsx                    # Toast notification system
│   ├── ProductPicker.jsx            # Searchable product picker
│   └── Sidebar.jsx                  # Navigation sidebar
├── lib/
│   ├── api.js                       # Fetch helpers (GET, POST, PATCH, DELETE)
│   ├── authGuard.js                 # Session check di API routes
│   ├── format.js                    # Format helpers (date, qty, divisi, dll)
│   ├── session.js                   # Token creation & verification
│   ├── store.js                     # Storage abstraction (KV + local fallback)
│   ├── users.js                     # Hardcoded user credentials
│   └── seed-data.json               # 1.676 produk dari file Excel
├── app/globals.css                  # All styling (minimalis, bukan norak)
├── .env.example                     # Environment variable template
├── .gitignore
├── package.json
└── next.config.mjs
```

## Customize

### Ganti Password Login
Edit `.env.local` (lokal) atau Vercel environment variable:
```
FARREL_PASSWORD=password_baru
AIM_PASSWORD=password_baru
```

### Ganti SESSION_SECRET (Production WAJIB)
```
SESSION_SECRET=string-acak-panjang-minimal-32-karakter
```

Tanpa ini, sesi login nggak aman di production. Generate di https://1password.com/password-generator

### Tambah Produk Baru
Login sebagai Farrel → Kelola Produk → Tambah Produk

Atau jika ingin reset ke data asli dari file Excel:
```bash
cp lib/seed-data.json ke KV atau .local-data.json
```

## Troubleshooting

**"Data hilang setelah di-redeploy"**
→ Setup Vercel KV Storage (lihat bagian 3 di atas)

**"Login nggak jalan"**
→ Pastikan NODE_ENV = production di Vercel env vars (biasanya sudah otomatis)

**"Password default nggak bisa login"**
→ Check `.env.example` — pastikan FARREL_PASSWORD dan AIM_PASSWORD benar

**"Excel export blank"**
→ Pastikan sudah ada data transaksi (coba input barang masuk/keluar dulu)

## Login Akun

- **Farrel** (Admin) — `admingudang` — bisa tambah/ubah/hapus produk
- **Aim** (Staff) — `admingudang` — cuma input transaksi & lihat stok

## Notes

- Design bukan norak — minimalis dengan aksen warna emas & garis tipis gunung di login
- Data dari file Excel `FORM_STO_JUNI_2026.xlsx` sudah diekstrak jadi 1.676 produk uniq dengan stok sesuai asli
- Authentication pakai HMAC-SHA256 token + httpOnly cookie, cukup aman buat operasional harian
- Bisa dijalankan lokal (`npm run dev`) atau production di Vercel
- Ada toast notification buat feedback setiap aksi, bukan pesan form statis yang norak

---

Pertanyaan? Baca dokumentasi Next.js di https://nextjs.org/docs atau file-file di project ini — sudah cukup comment.
