'use client';

import { useMemo, useState } from 'react';
import { Package, Search, X } from 'lucide-react';
import { fmtQty } from '@/lib/format';

export default function ProductPicker({ products, selected, onSelect }) {
  const [term, setTerm] = useState('');
  const [open, setOpen] = useState(false);

  const matches = useMemo(() => {
    if (!term.trim()) return [];
    const t = term.toLowerCase();
    return products.filter((p) => p.name.toLowerCase().includes(t)).slice(0, 8);
  }, [term, products]);

  if (selected) {
    return (
      <div className="picked-tag">
        <Package size={14} />
        <span>{selected.name}</span>
        <span className="stock-hint mono">stok: {fmtQty(selected.qty)} {selected.unit}</span>
        <button type="button" onClick={() => onSelect(null)} aria-label="Ganti produk">
          <X size={14} />
        </button>
      </div>
    );
  }

  return (
    <div className="picker">
      <div className="input-row">
        <Search size={16} />
        <input
          value={term}
          onChange={(e) => { setTerm(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Cari nama barang..."
          aria-label="Cari produk"
        />
      </div>
      {open && term.trim() && (
        <div className="picker-list">
          {matches.length === 0 ? (
            <div className="picker-empty">Tidak ada barang yang cocok dengan &quot;{term}&quot;.</div>
          ) : (
            matches.map((p) => (
              <div
                key={p.id}
                className="picker-item"
                onClick={() => { onSelect(p); setTerm(''); setOpen(false); }}
              >
                {p.name}
                <span className="unit-tag mono">{p.unit}</span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
