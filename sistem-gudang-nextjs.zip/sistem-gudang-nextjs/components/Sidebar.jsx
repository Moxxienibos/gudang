'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutGrid, ArrowDownToLine, ArrowUpFromLine, Boxes, History, Package,
  LogOut, User as UserIcon, ShieldCheck,
} from 'lucide-react';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutGrid },
  { href: '/masuk', label: 'Barang Masuk', icon: ArrowDownToLine },
  { href: '/keluar', label: 'Barang Keluar', icon: ArrowUpFromLine },
  { href: '/stok', label: 'Stok Barang', icon: Boxes, badgeKey: 'lowStock' },
  { href: '/riwayat', label: 'Riwayat Transaksi', icon: History },
  { href: '/produk', label: 'Kelola Produk', icon: Package, adminOnly: true },
];

export default function Sidebar({ user, lowStockCount = 0 }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    router.push('/login');
    router.refresh();
  }

  return (
    <div className="sidebar">
      <div className="sb-brand">
        <div className="badge"><span className="dot" />Stok &amp; Distribusi</div>
        <h2 className="disp">Sistem Gudang</h2>
      </div>
      <div className="sb-nav">
        {NAV_ITEMS.filter((it) => !it.adminOnly || user.role === 'admin').map((it) => {
          const active = pathname === it.href;
          const badge = it.badgeKey === 'lowStock' ? lowStockCount : 0;
          return (
            <Link key={it.href} href={it.href} className={`sb-item${active ? ' active' : ''}`}>
              <it.icon />
              <span>{it.label}</span>
              {!!badge && <span className="sb-badge">{badge}</span>}
            </Link>
          );
        })}
      </div>
      <div className="sb-foot">
        <div className="sb-user">
          <div className="av"><UserIcon size={16} /></div>
          <div>
            <div className="nm">{user.username}</div>
            <div className={`role-tag ${user.role}`}>
              {user.role === 'admin' ? <ShieldCheck size={11} /> : null}
              {user.role === 'admin' ? 'Admin' : 'Staff'}
            </div>
          </div>
        </div>
        <button className="sb-logout" onClick={logout}><LogOut size={14} />Keluar</button>
      </div>
    </div>
  );
}
