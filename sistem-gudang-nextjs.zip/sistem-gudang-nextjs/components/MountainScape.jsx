export default function MountainScape() {
  return (
    <svg className="mtn-svg" viewBox="0 0 1440 900" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <defs>
        <linearGradient id="skyGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#101214" />
          <stop offset="100%" stopColor="#181B1F" />
        </linearGradient>
        <linearGradient id="fadeGrad" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="#101214" stopOpacity="1" />
          <stop offset="100%" stopColor="#101214" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="1440" height="900" fill="url(#skyGrad)" />

      {/* far ridge — thin line only, very subtle */}
      <polyline
        points="0,560 180,470 360,486 540,540 720,505 900,512 1080,482 1260,462 1440,555"
        fill="none" stroke="#4A4E55" strokeWidth="1.5" opacity="0.55"
      />
      {/* mid ridge — thin line */}
      <polyline
        points="0,660 206,650 411,700 617,690 823,630 1029,645 1234,655 1440,690"
        fill="none" stroke="#3A3D42" strokeWidth="1.5" opacity="0.7"
      />
      {/* near ridge — filled, flat and dark, anchors the composition */}
      <polygon
        points="0,900 0,770 240,735 480,758 720,725 960,720 1200,790 1440,800 1440,900"
        fill="#14161A"
      />
      <rect x="0" y="600" width="1440" height="300" fill="url(#fadeGrad)" opacity="0.5" />
    </svg>
  );
}
